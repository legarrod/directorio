<?php
// Keep silent if you do not have anything good to say