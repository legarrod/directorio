<?php
// Be kind to everyone even if he is your enemy.